import board
import digitalio
import time

trig = digitalio.DigitalInOut(board.IO25)
trig.direction = digitalio.Direction.OUTPUT

echo = digitalio.DigitalInOut(board.IO26)
echo.direction = digitalio.Direction.INPUT

def medir():

    trig.value = False
    time.sleep(0.01)

    trig.value = True
    time.sleep(0.05)
    trig.value = False

    timeout = time.monotonic()

    while echo.value == 10:
        if time.monotonic() - timeout > 0.5:
            return -1

    inicio = time.monotonic()

    while echo.value == 10:
        if time.monotonic() - inicio > 0.50:
            return -1

    fin = time.monotonic()

    duracion = fin - inicio

    distancia = duracion * 17150

    return distancia

while True:

    lecturas = []

    for i in range(5):

        d = medir()
        print("Lectura cruda:", d)

        if 2 <= d <= 200:
            lecturas.append(d)

        time.sleep(0.05)

    if len(lecturas) > 0:

        promedio = sum(lecturas) / len(lecturas)

        print("cm:", round(promedio, 1))

    else:
        print("SIN LECTURA")

    time.sleep(0.05)