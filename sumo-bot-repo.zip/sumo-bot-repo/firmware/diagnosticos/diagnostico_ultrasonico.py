# ──────────────────────────────────────────────────────────────
#  DIAGNOSTICO HC-SR04 - Sumobot ESP32 / IdeaBoard
#  Uso: Carga este archivo SOLO (sin el codigo del sumobot).
#       Abre el monitor serial y observa las lecturas en vivo.
#       Presiona BOOT para cambiar entre modos de prueba.
# ──────────────────────────────────────────────────────────────

import board
import keypad
from ideaboard import IdeaBoard
from time import sleep, monotonic
import digitalio

ib = IdeaBoard()
keys = keypad.Keys((board.IO0,), value_when_pressed=False, pull=True)

# Pines HC-SR04
trig = digitalio.DigitalInOut(board.IO25)
trig.direction = digitalio.Direction.OUTPUT
trig.value = False

echo = digitalio.DigitalInOut(board.IO26)
echo.direction = digitalio.Direction.INPUT

# Configuracion
TIMEOUT_ECHO   = 0.03   # 30ms ~ 5 metros
MUESTRAS_STATS = 20     # Muestras para estadisticas
PAUSA_LECTURA  = 0.50    # Segundos entre lecturas continuas

# Modos (BOOT los cicla)
MODOS = ["CONTINUO", "ESTADISTICAS", "RANGO_MAXIMO"]
modo_actual = 0


# ─────────────────────────────────────────────────────────────
#  MEDIR DISTANCIA
# ─────────────────────────────────────────────────────────────
def medir_distancia_cm():
    # -1 = timeout sin eco (sin respuesta)
    # -2 = timeout eco largo (objeto pegado)
    trig.value = True
    sleep(0.00001)
    trig.value = False

    t_inicio = monotonic()
    t_subida = t_inicio
    t_bajada = t_inicio

    while not echo.value:
        t_subida = monotonic()
        if (t_subida - t_inicio) > TIMEOUT_ECHO:
            return -1

    while echo.value:
        t_bajada = monotonic()
        if (t_bajada - t_subida) > TIMEOUT_ECHO:
            return -2

    duracion  = t_bajada - t_subida
    distancia = (duracion * 34300) / 2
    return distancia


# ─────────────────────────────────────────────────────────────
#  BARRA VISUAL ASCII
# ─────────────────────────────────────────────────────────────
def barra_distancia(cm, max_cm=100, ancho=25):
    if cm < 0:
        return "[---- TIMEOUT ----]"
    cm_clamp = min(cm, max_cm)
    lleno = int((cm_clamp / max_cm) * ancho)
    vacio = ancho - lleno
    return "[" + "#" * lleno + "." * vacio + "]"


# ─────────────────────────────────────────────────────────────
#  COLOR LED segun distancia
# ─────────────────────────────────────────────────────────────
def color_por_distancia(cm):
    if cm < 0:
        return (255, 0, 0)      # Rojo: error
    elif cm < 15:
        return (255, 0, 0)      # Rojo: muy cerca
    elif cm < 35:
        return (255, 165, 0)    # Naranja: rango medio
    elif cm < 60:
        return (0, 255, 0)      # Verde: rango ideal
    else:
        return (0, 0, 255)      # Azul: lejos / limite


# ─────────────────────────────────────────────────────────────
#  MODO 1: LECTURA CONTINUA
# ─────────────────────────────────────────────────────────────
def modo_continuo():
    print("")
    print("==================================================")
    print("  MODO: LECTURA CONTINUA")
    print("  Acerca/aleja un objeto frente al sensor.")
    print("  Presiona BOOT para cambiar de modo.")
    print("==================================================")

    while True:
        event = keys.events.get()
        if event and event.released:
            return

        dist = medir_distancia_cm()
        ib.pixel = color_por_distancia(dist)

        if dist == -1:
            print("  [TIMEOUT] Sin eco - sensor desconectado o fuera de rango")
        elif dist == -2:
            print("  [TIMEOUT] Eco largo - objeto demasiado cerca (<2cm)")
        else:
            barra = barra_distancia(dist)
            print("  Distancia: " + str(round(dist, 1)) + " cm   " + barra)

        sleep(PAUSA_LECTURA)


# ─────────────────────────────────────────────────────────────
#  MODO 2: ESTADISTICAS
# ─────────────────────────────────────────────────────────────
def modo_estadisticas():
    print("")
    print("==================================================")
    print("  MODO: ESTADISTICAS (" + str(MUESTRAS_STATS) + " muestras)")
    print("  Manten el objeto quieto frente al sensor.")
    print("==================================================")

    muestras   = []
    errores    = 0
    timeouts_s = 0
    timeouts_b = 0

    ib.pixel = (255, 255, 0)

    for i in range(MUESTRAS_STATS):
        dist = medir_distancia_cm()
        prefijo = "  Muestra " + str(i + 1) + "/" + str(MUESTRAS_STATS) + ": "

        if dist == -1:
            print(prefijo + "TIMEOUT (sin eco)")
            timeouts_s += 1
            errores += 1
        elif dist == -2:
            print(prefijo + "TIMEOUT (eco largo)")
            timeouts_b += 1
            errores += 1
        else:
            print(prefijo + str(round(dist, 1)) + " cm")
            muestras.append(dist)

        sleep(0.15)

    print("")
    print("--------------------------------------------------")
    print("  RESULTADOS:")

    if muestras:
        promedio = sum(muestras) / len(muestras)
        minimo   = min(muestras)
        maximo   = max(muestras)
        varianza = sum((x - promedio) ** 2 for x in muestras) / len(muestras)
        desv_std = varianza ** 0.5

        print("  Lecturas validas : " + str(len(muestras)) + "/" + str(MUESTRAS_STATS))
        print("  Minimo           : " + str(round(minimo, 1)) + " cm")
        print("  Maximo           : " + str(round(maximo, 1)) + " cm")
        print("  Promedio         : " + str(round(promedio, 1)) + " cm")
        print("  Desv. estandar   : " + str(round(desv_std, 2)) + " cm  <- ruido del sensor")

        print("")
        print("  DIAGNOSTICO AUTOMATICO:")

        if desv_std < 1.0:
            print("  [OK] Sensor estable (ruido < 1 cm)")
        elif desv_std < 3.0:
            print("  [OK] Sensor aceptable (algo de ruido)")
        else:
            print("  [!!] Sensor inestable - revisa las conexiones")

        if maximo > 60:
            print("  [OK] Rango > 60 cm - apto para combate")
        elif maximo > 30:
            print("  [>>] Rango limitado (30-60 cm) - ajusta DIST_AVANCE")
        else:
            print("  [!!] Rango muy corto (<30 cm) - sensor posiblemente danado")

    if errores > 0:
        print("")
        print("  Errores: " + str(errores) + " de " + str(MUESTRAS_STATS) + " muestras")
        print("  Timeouts sin eco  : " + str(timeouts_s))
        print("  Timeouts eco largo: " + str(timeouts_b))
        if errores == MUESTRAS_STATS:
            print("  [!!] 100% errores - revisa TRIG(IO25) y ECHO(IO26)")

    print("--------------------------------------------------")
    ib.pixel = (0, 255, 0)
    print("  Presiona BOOT para continuar.")

    while True:
        event = keys.events.get()
        if event and event.released:
            return


# ─────────────────────────────────────────────────────────────
#  MODO 3: RANGO MAXIMO
# ─────────────────────────────────────────────────────────────
def modo_rango_maximo():
    print("")
    print("==================================================")
    print("  MODO: RANGO MAXIMO")
    print("  Aleja el objeto lentamente hasta que aparezca")
    print("  TIMEOUT. Esa es la distancia real del sensor.")
    print("  Presiona BOOT para cambiar de modo.")
    print("==================================================")

    consecutivos_timeout = 0
    ultima_valida        = 0.0

    while True:
        event = keys.events.get()
        if event and event.released:
            return

        dist = medir_distancia_cm()

        if dist < 0:
            consecutivos_timeout += 1
            ib.pixel = (255, 0, 0)
            print("  [TIMEOUT x" + str(consecutivos_timeout) + "]"
                  + "  ultima valida: " + str(round(ultima_valida, 1)) + " cm")
        else:
            consecutivos_timeout = 0
            ultima_valida        = dist
            ib.pixel = color_por_distancia(dist)
            barra = barra_distancia(dist, max_cm=150, ancho=25)
            print("  [OK] " + str(round(dist, 1)) + " cm  " + barra)

        sleep(0.12)


# ─────────────────────────────────────────────────────────────
#  EJECUCION PRINCIPAL
# ─────────────────────────────────────────────────────────────
print("")
print("##################################################")
print("  DIAGNOSTICO HC-SR04 - SUMOBOT")
print("  TRIG: IO25   ECHO: IO26")
print("  Presiona BOOT para cambiar de modo.")
print("##################################################")

ib.pixel = (0, 255, 255)
sleep(1)

while True:
    nombre_modo = MODOS[modo_actual]

    if nombre_modo == "CONTINUO":
        modo_continuo()
    elif nombre_modo == "ESTADISTICAS":
        modo_estadisticas()
    elif nombre_modo == "RANGO_MAXIMO":
        modo_rango_maximo()

    modo_actual = (modo_actual + 1) % len(MODOS)
    print("")
    print("  -> Cambiando a modo: " + MODOS[modo_actual])
    sleep(0.5)
