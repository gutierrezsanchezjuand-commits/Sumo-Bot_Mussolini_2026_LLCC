import board
import time
from hcsr04 import HCSR04

# Asegúrate de que TRIG está en IO25 y ECHO en IO26
sonar = HCSR04(board.IO25, board.IO26)

print("Iniciando diagnóstico del sensor ultrasónico...")

while True:
    try:
        distancia = sonar.dist_cm()
        print("Distancia real leída:", distancia, "cm")
    except RuntimeError as e:
        print("Error del sensor (RuntimeError):", e)
    except Exception as e:
        print("Error desconocido:", e)
        
    # Medio segundo de pausa para poder leer la pantalla tranquilamente
    time.sleep(0.5)
    